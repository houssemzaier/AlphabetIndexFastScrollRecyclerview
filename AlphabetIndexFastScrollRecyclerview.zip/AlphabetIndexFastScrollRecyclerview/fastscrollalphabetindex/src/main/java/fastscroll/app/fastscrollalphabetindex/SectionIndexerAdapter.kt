package fastscroll.app.fastscrollalphabetindex

import android.support.v7.widget.RecyclerView
import android.widget.SectionIndexer

abstract class SectionIndexerAdapter<VH : RecyclerView.ViewHolder?> : RecyclerView.Adapter<VH>(), SectionIndexer
