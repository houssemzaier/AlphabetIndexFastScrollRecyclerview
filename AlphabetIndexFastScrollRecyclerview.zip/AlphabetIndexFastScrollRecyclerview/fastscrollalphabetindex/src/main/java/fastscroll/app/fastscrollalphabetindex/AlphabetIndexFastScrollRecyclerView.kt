package fastscroll.app.fastscrollalphabetindex

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Typeface
import android.support.annotation.ColorInt
import android.support.annotation.ColorRes
import android.support.v4.content.ContextCompat
import android.support.v7.widget.RecyclerView
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.GestureDetector.SimpleOnGestureListener
import android.view.MotionEvent

class AlphabetIndexFastScrollRecyclerView @JvmOverloads constructor(
        context: Context,
        attrs: AttributeSet? = null,
        defStyle: Int = 0
) : RecyclerView(context, attrs, defStyle) {
    private val section = AlphabetIndexFastScrollRecyclerSection(context, this)

    //region visibility for IndexBar or Preview
    var isIndexBarVisible = true
        set(value) {
            field = value
            section.isIndexBarVisible(value)
        }

    fun isPreviewVisible(isVisible: Boolean) {
        section.isPreviewVisible(isVisible)
    }
    //endregion visibility for IndexBar or Preview

    //region IndexBarLayout
    var indexBarWidth = 20f
        set(value) {
            field = value
            section.setIndexBarWidth(value)
        }

    var indexBarMargin = 5f
        set(value) {
            field = value
            section.setIndexBarMargin(value)
        }

    var indexBarCornerRadius = 5
        set(value) {
            field = value
            section.setIndexBarCornerRadius(value)
        }
    //endregion IndexBarLayout

    //region IndexBarBackground
    @JvmField
    @ColorInt
    var indexBarBackgroundColor = Color.BLACK

    /*** @param color The color for the index bar*/
    fun setIndexBarBackgroundColor(color: String?) {
        val colorValue = Color.parseColor(color)
        indexBarBackgroundColor = colorValue
        section.setIndexBarBackgroundColor(indexBarBackgroundColor)
    }

    /*** @param color The color for the index bar*/
    fun setIndexBarBackgroundColor(@ColorRes color: Int) {
        val colorValue = ContextCompat.getColor(context, color)
        indexBarBackgroundColor = colorValue
        section.setIndexBarBackgroundColor(indexBarBackgroundColor)
    }

    var indexBarTransparentValue = 0.6F
        set(value) {
            field = value
            section.setIndexBarTransparentValue(value)
        }
    //endregion IndexBarBackground

    //region IndexTextSize color highlightColor
    var indexBarTextSize = 12
        set(value) {
            field = value
            section.setIndexBarTextSize(value)
        }

    @JvmField
    @ColorInt
    var indexBarTextColor = Color.WHITE

    fun setIndexBarTextColor(color: String?) {
        val colorValue = Color.parseColor(color)
        indexBarTextColor = colorValue
        section.setIndexBarTextColor(indexBarTextColor)
    }

    fun setIndexBarTextColor(@ColorRes color: Int) {
        val colorValue = ContextCompat.getColor(context, color)
        indexBarTextColor = colorValue
        section.setIndexBarTextColor(colorValue)
    }

    @JvmField
    @ColorInt
    var indexBarHighLateTextColor = Color.BLACK

    fun setIndexBarHighlightTextColor(color: String?) {
        val colorValue = Color.parseColor(color)
        indexBarHighLateTextColor = colorValue
        section.setIndexBarHighlightTextColor(indexBarHighLateTextColor)
    }

    fun setIndexBarHighlightTextColor(@ColorRes color: Int) {
        val colorValue = ContextCompat.getColor(context, color)
        indexBarHighLateTextColor = colorValue
        section.setIndexBarHighlightTextColor(indexBarHighLateTextColor)
    }

    /*** @param shown boolean to show or hide the index bar*/
    fun setIndexBarHighlightTextVisibility(shown: Boolean) {
        section.isIndexBarHighlightTextVisibility(shown)
    }
    //endregion IndexTextSize color highlightColor

    //PreviewPadding
    var previewPadding = 5
        set(value) {
            field = value
            section.setPreviewPadding(value)
        }

    //Section Helper class
    var adapter: SectionIndexerAdapter<*>? = null
        set(value) {
            field = value
            super.setAdapter(adapter)
            section.setAdapter(adapter)
        }
    private var gestureDetector = GestureDetector(context, SimpleOnGestureListener())

    init {
        if (attrs != null) {
            val typedArray = context.obtainStyledAttributes(attrs, R.styleable.AlphabetIndexFastScrollRecyclerView, 0, 0)
            if (typedArray != null) {
                try {
                    //IndexBarLayout
                    indexBarWidth = typedArray.getFloat(R.styleable.AlphabetIndexFastScrollRecyclerView_setIndexBarWidth, indexBarWidth)
                    indexBarMargin = typedArray.getFloat(R.styleable.AlphabetIndexFastScrollRecyclerView_setIndexBarMargin, indexBarMargin)
                    indexBarCornerRadius = typedArray.getInt(R.styleable.AlphabetIndexFastScrollRecyclerView_setIndexBarCornerRadius, indexBarCornerRadius)

                    //IndexBarBackground
                    if (typedArray.hasValue(R.styleable.AlphabetIndexFastScrollRecyclerView_setIndexBarBackgroundColor)) {
                        indexBarBackgroundColor = Color.parseColor(typedArray.getString(R.styleable.AlphabetIndexFastScrollRecyclerView_setIndexBarBackgroundColor))
                    }
                    if (typedArray.hasValue(R.styleable.AlphabetIndexFastScrollRecyclerView_setIndexBarColorBackgroundRes)) {
                        indexBarBackgroundColor = typedArray.getColor(R.styleable.AlphabetIndexFastScrollRecyclerView_setIndexBarColorBackgroundRes, indexBarBackgroundColor)
                    }
                    indexBarTransparentValue = typedArray.getFloat(R.styleable.AlphabetIndexFastScrollRecyclerView_setIndexBarTransparentValue, indexBarTransparentValue)

                    //IndexBar(TextSize+Color+
                    indexBarTextSize = typedArray.getInt(R.styleable.AlphabetIndexFastScrollRecyclerView_setIndexBarTextSize, indexBarTextSize)
                    if (typedArray.hasValue(R.styleable.AlphabetIndexFastScrollRecyclerView_setIndexBarTextColor)) {
                        indexBarTextColor = Color.parseColor(typedArray.getString(R.styleable.AlphabetIndexFastScrollRecyclerView_setIndexBarTextColor))
                    }
                    if (typedArray.hasValue(R.styleable.AlphabetIndexFastScrollRecyclerView_setIndexBarTextColorRes)) {
                        indexBarTextColor = typedArray.getColor(R.styleable.AlphabetIndexFastScrollRecyclerView_setIndexBarTextColorRes, indexBarTextColor)
                    }
                    if (typedArray.hasValue(R.styleable.AlphabetIndexFastScrollRecyclerView_setIndexBarHighlightTextColor)) {
                        indexBarHighLateTextColor = Color.parseColor(typedArray.getString(R.styleable.AlphabetIndexFastScrollRecyclerView_setIndexBarHighlightTextColor))
                    }
                    if (typedArray.hasValue(R.styleable.AlphabetIndexFastScrollRecyclerView_setIndexBarHighlightTextColorRes)) {
                        indexBarHighLateTextColor = typedArray.getColor(R.styleable.AlphabetIndexFastScrollRecyclerView_setIndexBarHighlightTextColor, indexBarHighLateTextColor)
                    }

                    //PreviewPadding
                    previewPadding = typedArray.getInt(R.styleable.AlphabetIndexFastScrollRecyclerView_setPreviewPadding, previewPadding)
                } finally {
                    typedArray.recycle()
                }
            }
        }
    }

    override fun onSizeChanged(width: Int, height: Int, oldWidth: Int, oldHeight: Int) {
        super.onSizeChanged(width, height, oldWidth, oldHeight)
        section.onSizeChanged(width, height, oldWidth, oldHeight)
    }

    override fun draw(canvas: Canvas) {
        super.draw(canvas)
        section.draw(canvas)
    }

    override fun onInterceptTouchEvent(event: MotionEvent): Boolean {
        return if (isIndexBarVisible && section.contains(event.x, event.y)) {
            true
        } else super.onInterceptTouchEvent(event)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (isIndexBarVisible) {
            // Intercept ListView's touch event
            if (section.onTouchEvent(event)) {
                return true
            }
            gestureDetector.onTouchEvent(event)
        }
        return super.onTouchEvent(event)
    }

    /*** @param typeface Typeface to set the typeface of the preview & the index bar*/
    fun setTypeface(typeface: Typeface?) {
        section.setTypeface(typeface)
    }
}
