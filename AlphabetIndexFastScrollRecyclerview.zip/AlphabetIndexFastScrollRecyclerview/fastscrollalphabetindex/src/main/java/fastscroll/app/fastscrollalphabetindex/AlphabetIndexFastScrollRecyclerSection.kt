package fastscroll.app.fastscrollalphabetindex

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.*
import android.os.Handler
import android.os.Message
import android.os.SystemClock
import android.support.annotation.ColorInt
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView.AdapterDataObserver
import android.util.Log
import android.view.MotionEvent

class AlphabetIndexFastScrollRecyclerSection internal constructor(context: Context, rv: AlphabetIndexFastScrollRecyclerView) : AdapterDataObserver() {
    private var isIndexBarVisible = true
    private var isPreviewVisible = true
    private var isIndexBarHighlightTextVisibility = false
    private val density: Float
    private val scaledDensity: Float

    //IndexBarLayout
    private var indexBarWidth: Float
    private var indexBarMargin: Float
    private var indexBarCornerRadius: Float

    //IndexBarBackground
    @ColorInt
    private var indexBarBackgroundColor: Int
    private var indexBarBackgroundAlpha: Int

    //IndexTextSize color highlightColor
    private var indexBarTextSize: Int

    @ColorInt
    private var indexBarTextColor: Int

    @ColorInt
    private var indexBarHighlightTextColor: Int

    //PreviewPadding
    private var previewPadding: Float

    //paints
    private val indexBarPaint: Paint
    private val previewPaint: Paint
    private val indexBarTextPaint: Paint
    private val previewTextPaint: Paint

    private var typeface: Typeface? = null
    private var sectionWidth = 0
    private var sectionHeight = 0
    private var indexBarRect: RectF? = null
    private lateinit var recyclerView: AlphabetIndexFastScrollRecyclerView
    private lateinit var sectionIndexerAdapter: SectionIndexerAdapter<*>

    @SuppressLint("HandlerLeak")
    private val mHandler: Handler = object : Handler() {
        override fun handleMessage(msg: Message) {
            super.handleMessage(msg)
            if (msg.what == WHAT_FADE_PREVIEW) {
                recyclerView.invalidate()
            }
        }
    }
    private var currentSection = -1
    private lateinit var sections: Array<String>
    private var isIndexing = false
    private fun convertTransparentValueToBackgroundAlpha(value: Float): Int {
        return (255 * value).toInt()
    }

    fun setAdapter(adapter: SectionIndexerAdapter<*>?) {
        if (adapter == null) return
        sectionIndexerAdapter = adapter
        sectionIndexerAdapter.registerAdapterDataObserver(this)
        sections = sectionIndexerAdapter.getSections() as Array<String>
    }

    fun onSizeChanged(currentWidth: Int, currentHeight: Int, oldWidth: Int, oldHeight: Int) {
        sectionWidth = currentWidth
        sectionHeight = currentHeight
        indexBarRect = RectF(currentWidth - indexBarMargin - indexBarWidth
                , indexBarMargin
                , currentWidth - indexBarMargin
                , currentHeight - indexBarMargin)
    }

    fun draw(canvas: Canvas) {
        if (!isIndexBarVisible) return
        indexBarPaint.color = indexBarBackgroundColor
        indexBarPaint.alpha = indexBarBackgroundAlpha
        indexBarPaint.isAntiAlias = true
        canvas.drawRoundRect(indexBarRect, indexBarCornerRadius, indexBarCornerRadius, indexBarPaint)
        if (sections != null && sections!!.size > 0) {
            // Preview is shown when mCurrentSection is set
            if (isPreviewVisible && currentSection >= 0 && sections!![currentSection] != "") {
                previewPaint.color = Color.BLACK
                previewPaint.alpha = 96
                previewPaint.isAntiAlias = true
                previewPaint.setShadowLayer(3f, 0f, 0f, Color.argb(64, 0, 0, 0))
                previewTextPaint.color = Color.WHITE
                previewTextPaint.isAntiAlias = true
                previewTextPaint.textSize = 50 * scaledDensity
                previewTextPaint.typeface = typeface
                val previewTextWidth = previewTextPaint.measureText(sections!![currentSection])
                val previewSize = 2 * previewPadding + previewTextPaint.descent() - previewTextPaint.ascent()
                val previewRect = RectF((sectionWidth - previewSize) / 2
                        , (sectionHeight - previewSize) / 2
                        , (sectionWidth - previewSize) / 2 + previewSize
                        , (sectionHeight - previewSize) / 2 + previewSize)
                canvas.drawRoundRect(previewRect, 5 * density, 5 * density, previewPaint)
                canvas.drawText(sections!![currentSection], previewRect.left + (previewSize - previewTextWidth) / 2 - 1
                        , previewRect.top + previewPadding - previewTextPaint.ascent() + 1, previewTextPaint)
                invalidateAfter(2200)
            }
            indexBarTextPaint.color = indexBarTextColor
            indexBarTextPaint.isAntiAlias = true
            indexBarTextPaint.textSize = indexBarTextSize * scaledDensity
            indexBarTextPaint.typeface = typeface
            val sectionHeight = (indexBarRect!!.height() - 2 * indexBarMargin) / sections!!.size
            val paddingTop = (sectionHeight - (indexBarTextPaint.descent() - indexBarTextPaint.ascent())) / 2
            for (i in sections!!.indices) {
                if (isIndexBarHighlightTextVisibility) {
                    if (currentSection > -1 && i == currentSection) {
                        indexBarTextPaint.typeface = Typeface.create(typeface, Typeface.BOLD)
                        indexBarTextPaint.textSize = (indexBarTextSize + 3) * scaledDensity
                        indexBarTextPaint.color = indexBarHighlightTextColor
                    } else {
                        indexBarTextPaint.typeface = typeface
                        indexBarTextPaint.textSize = indexBarTextSize * scaledDensity
                        indexBarTextPaint.color = indexBarTextColor
                    }
                    val paddingLeft = (indexBarWidth - indexBarTextPaint.measureText(sections!![i])) / 2
                    canvas.drawText(sections!![i], indexBarRect!!.left + paddingLeft
                            , indexBarRect!!.top + indexBarMargin + sectionHeight * i + paddingTop - indexBarTextPaint.ascent(), indexBarTextPaint)
                } else {
                    val paddingLeft = (indexBarWidth - indexBarTextPaint.measureText(sections!![i])) / 2
                    canvas.drawText(sections!![i], indexBarRect!!.left + paddingLeft
                            , indexBarRect!!.top + indexBarMargin + sectionHeight * i + paddingTop - indexBarTextPaint.ascent(), indexBarTextPaint)
                }
            }
        }
    }

    private fun invalidateAfter(delay: Long) {
        mHandler.removeMessages(WHAT_FADE_PREVIEW)
        mHandler.sendEmptyMessageAtTime(WHAT_FADE_PREVIEW, SystemClock.uptimeMillis() + delay)
    }

    fun onTouchEvent(ev: MotionEvent): Boolean {
        when (ev.action) {
            MotionEvent.ACTION_DOWN ->                 // If down event occurs inside index bar region, start indexing
                if (contains(ev.x, ev.y)) {
                    // It demonstrates that the motion event started from index bar
                    isIndexing = true
                    // Determine which section the point is in, and move the list to that section
                    currentSection = getSectionByPoint(ev.y)
                    scrollToPosition()
                    return true
                }
            MotionEvent.ACTION_MOVE -> if (isIndexing) {
                // If this event moves inside index bar
                if (contains(ev.x, ev.y)) {
                    // Determine which section the point is in, and move the list to that section
                    currentSection = getSectionByPoint(ev.y)
                    scrollToPosition()
                }
                return true
            }
            MotionEvent.ACTION_UP -> if (isIndexing) {
                isIndexing = false
                currentSection = -1
            }
        }
        return false
    }

    private fun scrollToPosition() {
        try {
            val position = sectionIndexerAdapter!!.getPositionForSection(currentSection)
            val layoutManager = recyclerView.layoutManager
            if (layoutManager is LinearLayoutManager) {
                layoutManager.scrollToPositionWithOffset(position, 0)
            } else {
                layoutManager.scrollToPosition(position)
            }
        } catch (e: Exception) {
            Log.d("INDEX_BAR", "Data size returns null")
        }
    }

    override fun onChanged() {
        super.onChanged()
        sections = sectionIndexerAdapter!!.sections as Array<String>
    }

    fun contains(x: Float, y: Float): Boolean {
        // Determine if the point is in index bar region, which includes the right margin of the bar
        return x >= indexBarRect!!.left && y >= indexBarRect!!.top && y <= indexBarRect!!.top + indexBarRect!!.height()
    }

    private fun getSectionByPoint(y: Float): Int {
        if (sections == null || sections!!.size == 0) return 0
        if (y < indexBarRect!!.top + indexBarMargin) return 0
        return if (y >= indexBarRect!!.top + indexBarRect!!.height() - indexBarMargin) sections!!.size - 1 else ((y - indexBarRect!!.top - indexBarMargin) / ((indexBarRect!!.height() - 2 * indexBarMargin) / sections!!.size)).toInt()
    }

    /**
     * @param value int to set the text size of the index bar
     */
    fun setIndexBarTextSize(value: Int) {
        indexBarTextSize = value
    }

    /**
     * @param value float to set the width of the index bar
     */
    fun setIndexBarWidth(value: Float) {
        indexBarWidth = value * density
    }

    /**
     * @param value float to set the margin of the index bar
     */
    fun setIndexBarMargin(value: Float) {
        indexBarMargin = value * density
    }

    /**
     * @param value int to set preview padding
     */
    fun setPreviewPadding(value: Int) {
        previewPadding = value.toFloat()
    }

    /**
     * @param value int to set the radius of the index bar
     */
    fun setIndexBarCornerRadius(value: Int) {
        indexBarCornerRadius = value * density
    }

    /**
     * @param value float to set the transparency of the color for index bar
     */
    fun setIndexBarTransparentValue(value: Float) {
        indexBarBackgroundAlpha = convertTransparentValueToBackgroundAlpha(value)
    }

    /**
     * @param typeface Typeface to set the typeface of the preview & the index bar
     */
    fun setTypeface(typeface: Typeface?) {
        this.typeface = typeface
    }

    /**
     * @param isVisible boolean to show or hide the index bar
     */
    fun isIndexBarVisible(isVisible: Boolean) {
        isIndexBarVisible = isVisible
        recyclerView.invalidate()
    }

    /**
     * @param isVisible boolean to show or hide the preview box
     */
    fun isPreviewVisible(isVisible: Boolean) {
        isPreviewVisible = isVisible
    }

    /**
     * @param color The color for the scroll track
     */
    fun setIndexBarBackgroundColor(@ColorInt color: Int) {
        indexBarBackgroundColor = color
    }

    /**
     * @param color The text color for the index bar
     */
    fun setIndexBarTextColor(@ColorInt color: Int) {
        indexBarTextColor = color
    }

    /**
     * @param color The text color for the index bar
     */
    fun setIndexBarHighlightTextColor(@ColorInt color: Int) {
        indexBarHighlightTextColor = color
    }

    /**
     * @param isVisible boolean to show or hide the index bar
     */
    fun isIndexBarHighlightTextVisibility(isVisible: Boolean) {
        isIndexBarHighlightTextVisibility = isVisible
    }

    companion object {
        private const val WHAT_FADE_PREVIEW = 1
    }

    init {
        //density
        density = context.resources.displayMetrics.density
        //scaledDensity
        scaledDensity = context.resources.displayMetrics.scaledDensity
        recyclerView = rv

        //IndexBarLayout
        indexBarWidth = recyclerView.indexBarWidth * density
        indexBarMargin = recyclerView.indexBarMargin * density
        indexBarCornerRadius = recyclerView.indexBarCornerRadius * density

        //IndexBarBackground
        indexBarBackgroundColor = recyclerView.indexBarBackgroundColor
        indexBarBackgroundAlpha = convertTransparentValueToBackgroundAlpha(recyclerView.indexBarTransparentValue)

        //IndexTextSize
        indexBarTextSize = recyclerView.indexBarTextSize
        indexBarTextColor = recyclerView.indexBarTextColor
        indexBarHighlightTextColor = recyclerView.indexBarHighLateTextColor

        //PreviewPadding
        previewPadding = recyclerView.previewPadding * density

        //setAdapter(recyclerView.getAdapter());
        indexBarPaint = Paint()
        indexBarTextPaint = Paint()
        previewPaint = Paint()
        previewTextPaint = Paint()
    }
}
